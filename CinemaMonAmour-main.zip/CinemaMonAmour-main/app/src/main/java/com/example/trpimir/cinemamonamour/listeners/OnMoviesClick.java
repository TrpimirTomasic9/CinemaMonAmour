package com.example.trpimir.cinemamonamour.listeners;

import com.example.trpimir.cinemamonamour.models.Movie;

public interface OnMoviesClick {
    void onClick(Movie movie);
}
