package com.example.trpimir.cinemamonamour.listeners;

import com.example.trpimir.cinemamonamour.models.FavMovie;

public interface OnFavClick {
    void OnClick(FavMovie favMovie);
}
